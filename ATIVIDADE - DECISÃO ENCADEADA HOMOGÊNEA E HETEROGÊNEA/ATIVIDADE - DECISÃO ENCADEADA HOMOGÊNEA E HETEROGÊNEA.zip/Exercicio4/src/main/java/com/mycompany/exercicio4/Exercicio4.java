
package com.mycompany.exercicio4;

import java.util.Scanner;

public class Exercicio4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        
        // Pede ao usuário que digite um número de 1 a 12
        System.out.println("Digite um numero de 1 a 12: ");
        int numero = scanner.nextInt();
        
        // Processa a escolha do usuario atraves da estrutura switch-case
        switch(numero){
            case 1:
                System.out.println("Janeiro");
                break;
            case 2:
                System.out.println("Fevereiro");
                break;
            case 3:
                System.out.println("Março");
                break;
            case 4:
                System.out.println("O mes é: Abril");
                break;
            case 5:
                System.out.println("O mes é: Maio");
                break;
            case 6:
                System.out.println("O mes é: Junho");
                break;
            case 7:
                System.out.println("O mes é: Julho");
                break;
            case 8:
                System.out.println("O mes é: Agosto");
                break;
            case 9:
                System.out.println("O mes é: Setembro");
                break;
            case 10:
                System.out.println("O mes é: Outubro");
                break;
            case 11:
                System.out.println("O mes é: Novembro");
                break;
            case 12:
                System.out.println("O mes é: Dezembro");
                break;
            default:
                System.out.println("Numero fora do intervalo permitido. Insira um numero entre 1 e 12.");
                break;
        }
    }
}
